ram = require "ram"
cpu = require "cpu"
require "draw"

local totalTime = 0
local cpuHZ = 1000 --1000hz
local timestep = 1 / cpuHZ

ram.store(1, "C/BIOS/bios", "string")
ram.store(2, "C/OS/os", "string")

function love.load()
  cpu.load()
end

function love.update(dt)
  totalTime = totalTime + dt
  while totalTime > timestep do
    cpu.update(timestep)
    totalTime = totalTime - timestep
  end
end

function love.keypressed(key, scancode, is_repeat)
  cpu.execute("input", {key})
end

function love.draw()
  cpu.draw()
  love.graphics.setColor(1,1,1,1)
  love.graphics.print(love.timer.getFPS())
end
