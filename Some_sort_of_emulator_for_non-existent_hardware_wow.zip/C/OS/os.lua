local os = {}

--Store state in ram spot 3

function os.input(key)
  if key == "f1" then
    ram.store(3, "help", "string")
  end
end

function os.update(dt)
  if ram.get(3) and ram.get(3).value == "help" then
    color(1,0,0)
    rect("fill", 0,0, 192,128)
    color(0,1,0)
    rect("fill",5,5, 187,123)
  end
end

return os
