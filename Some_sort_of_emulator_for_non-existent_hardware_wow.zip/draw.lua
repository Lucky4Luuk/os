function color(r,g,b)
  love.graphics.setColor(r,g,b,1)
end

function rect(mode, x1,y1, x2,y2)
  local w = x2 - x1
  local h = y2 - y1
  love.graphics.rectangle(mode, x1,y1, w,h)
end
