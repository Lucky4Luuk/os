function love.conf(t)
  t.console = true
  t.window.vsync = false
end
